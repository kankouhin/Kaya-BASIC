
#include "core.h"
#include <windows.h>
#include <stdlib.h>
#include <locale.h>
#include <stdio.h>
#include <exception>

#include <windows.h>
#include <excpt.h>

LPTOP_LEVEL_EXCEPTION_FILTER pOldFilter;

using namespace bpp;

extern "C" void abort_with_error(const string& s)
{
	string err = string("Error: ") + s + string("\r\n");

	while (true)
	{
		static bool first = true;
		int line = dbg_getline();
		string func = dbg_getfunc();
		if (!line)
			break;
		if (first)
		{
			err = err + string("    raised");
			first = false;
		}
		else
			err = err + string(",\r\n    called");
		err = err + string(" by ") + func + string("() at line #") + line;
	}
	err = err + string("\r\n");

	MessageBox(0, err.cstr(), "Error", 0x10);
	
	SetUnhandledExceptionFilter(pOldFilter);
	ExitProcess(0);
}

void bpp_terminate_handler()
{
	abort_with_error("");
}

#if defined(__x86_64)
	extern "C" long process_se(EXCEPTION_POINTERS *pointers)
	{
	    switch (pointers->ExceptionRecord->ExceptionCode) {
		case EXCEPTION_ACCESS_VIOLATION:
			abort_with_error("access violation(null pointer)");
		case EXCEPTION_FLT_DIVIDE_BY_ZERO:
		case EXCEPTION_INT_DIVIDE_BY_ZERO:
			abort_with_error("division by zero");
		case EXCEPTION_FLT_INVALID_OPERATION:
			abort_with_error("floating-point error");
		case EXCEPTION_ILLEGAL_INSTRUCTION:
			abort_with_error("illegal instruction");
		case EXCEPTION_STACK_OVERFLOW:
			abort_with_error("stack overflow");
		default:
	        abort_with_error("unknown error");
		}
		return 1;
	}

#else
	extern "C" long process_se(struct _EXCEPTION_RECORD* er, void* buf, struct _CONTEXT* ctx, void* buf2)
	{
		switch (er->ExceptionCode)
		{
		case EXCEPTION_ACCESS_VIOLATION:
			abort_with_error("access violation(null pointer)");
		case EXCEPTION_FLT_DIVIDE_BY_ZERO:
		case EXCEPTION_INT_DIVIDE_BY_ZERO:
			abort_with_error("division by zero");
		case EXCEPTION_FLT_INVALID_OPERATION:
			abort_with_error("floating-point error");
		case EXCEPTION_ILLEGAL_INSTRUCTION:
			abort_with_error("illegal instruction");
		case EXCEPTION_STACK_OVERFLOW:
			abort_with_error("stack overflow");
		default:
	        abort_with_error("unknown error");
		}
		return 1;
	}
#endif


LONG WINAPI UnhandledExceptionFilter2(LPEXCEPTION_POINTERS pep)
{
	switch (pep->ExceptionRecord->ExceptionCode)
	{
	case EXCEPTION_ACCESS_VIOLATION:
		abort_with_error("access violation(null pointer)");
	case EXCEPTION_FLT_DIVIDE_BY_ZERO:
	case EXCEPTION_INT_DIVIDE_BY_ZERO:
		abort_with_error("division by zero");
	case EXCEPTION_FLT_INVALID_OPERATION:
		abort_with_error("floating-point error");
	case EXCEPTION_ILLEGAL_INSTRUCTION:
		abort_with_error("illegal instruction");
	case EXCEPTION_STACK_OVERFLOW:
		abort_with_error("stack overflow");
	default:
        abort_with_error("unknown error");
	}
	return 0;
}

int APIENTRY WinMain(HINSTANCE, HINSTANCE, LPSTR, int)
{
	//std::set_terminate(bpp_terminate_handler);
	
	pOldFilter = SetUnhandledExceptionFilter(UnhandledExceptionFilter2);
	
	argc = 0;
	CoInitialize(NULL);
	
	try
	{
		//__try1(process_se) // not works on x64
			__init_all();
			Main();
			__final_all();
		//__except1;
        //{
            //cout << "Exception Caught" << endl;
        //}
	}
	catch (const string& s)
	{
		abort_with_error(s);
	}
	catch (...)
	{
		abort_with_error("");
	}
	
	CoUninitialize();
	return 0;
}

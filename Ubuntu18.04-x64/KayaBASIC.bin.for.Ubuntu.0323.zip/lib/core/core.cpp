#include "core.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>

// for PRINT
//#include <conio.h>


#ifdef __GNUWIN32__
	#include <windows.h>
#else
	#define _cprintf printf
#endif

#include <vector>
#include <map>


namespace bpp
{

Print print;
Input input;

struct __rtti_object: rtti
{
	__rtti_object() { next = 0; }
	string name() { return "OBJECT"; }
	ref<object> create() { return new object; }
} __rtti_object;

rtti* classlist::list = &__rtti_object;


string::string()
{
	dyn = (string_t*) calloc(4 + 4 + 1, 1);
	dyn->count = 1;
}


string::string(const char* s)
{
	if (s >= (char*)0x10000)
	{
		int len = strlen(s);
		dyn = (string_t*) calloc(4 + 4 + len + 1, 1);
		dyn->count = 1;
		dyn->len = len;
		memcpy(dyn->data, s, len);
	}
	else
		dyn = (string_t*)(s);
}


string::string(const string& s)
{
	dyn = s.dyn;
	if (dyn >= (string_t*)0x10000)
		dyn->count++;
}


void string::release()
{
	if (dyn >= (string_t*)0x10000)
		if (!--dyn->count)
			free(dyn);
}


void string::alloc(int count)
{
	release();
	dyn = (string_t*) calloc(4 + 4 + count + 1, 1);
	dyn->count = 1;
	dyn->len = count;
}


int string::length() const
{
	if (dyn >= (string_t*)0x10000)
		return dyn->len;
	else
		return 0;
}


string& string::operator= (const string& s)
{
	release();
	dyn = s.dyn;
	if (dyn >= (string_t*)0x10000)
		dyn->count++;
	return *this;
}


string& string::operator= (const variant& v)
{
	return *this = string(v);
}


string& string::operator+= (const string& s)
{
	return *this = *this + s;
}


string& string::operator-= (const string& s)
{
	return *this = *this - s;
}


string& string::operator*= (const string& s)
{
	return *this = *this * s;
}


string& string::operator/= (const string& s)
{
	return *this = *this / s;
}


string& string::operator+= (const variant& s)
{
	return *this += string(s);
}


string& string::operator-= (const variant& s)
{
	return *this -= string(s);
}


string& string::operator*= (const variant& s)
{
	return *this *= string(s);
}


string& string::operator/= (const variant& s)
{
	return *this /= string(s);
}


string string::operator+ (const string& s) const
{
	if (dyn >= (string_t*)0x10000 && s.dyn >= (string_t*)0x10000)
	{
		int l1 = length(), l2 = s.length();
		string_t* result = (string_t*) calloc(4 + 4 + l1 + l2 + 1, 1);
		result->count = 1;
		result->len = l1 + l2;
		memcpy(result->data, dyn->data, l1);
		memcpy(result->data + l1, s.dyn->data, l2);
		return result;
	}
	else
		return string();
}


string string::operator+ (double n) const
{
	variant vs = variant(n);
	string s = vs;
	if (dyn >= (string_t*)0x10000 && s.dyn >= (string_t*)0x10000)
	{
		int l1 = length(), l2 = s.length();
		string_t* result = (string_t*) calloc(4 + 4 + l1 + l2 + 1, 1);
		result->count = 1;
		result->len = l1 + l2;
		memcpy(result->data, dyn->data, l1);
		memcpy(result->data + l1, s.dyn->data, l2);
		return result;
	}
	else
		return string();
}


int string::cmp(const string& s) const
{
	if (dyn >= (string_t*)0x10000 && s.dyn >= (string_t*)0x10000)
	{
		int l1 = length(), l2 = s.length();
		if (l1 == l2)
			return memcmp(dyn->data, s.dyn->data, l1);
		else
		{
			int len = (l1 < l2 ? l1 : l2);
			int result = memcmp(dyn->data, s.dyn->data, len);
			if (!result)
				return l1 - l2;
			else
				return result;
		}
	}
	else
		return 1;
}


bool string::operator== (const string& s) const
{
	return !cmp(s);
}


bool string::operator!= (const string& s) const
{
	return cmp(s);
}


bool string::operator< (const string& s) const
{
	return cmp(s) < 0;
}


bool string::operator> (const string& s) const
{
	return cmp(s) > 0;
}


bool string::operator<= (const string& s) const
{
	return cmp(s) <= 0;
}


bool string::operator>= (const string& s) const
{
	return cmp(s) >= 0;
}


string& string::operator++ ()
{
	return *this = double(variant(*this)) + 1;
}


string& string::operator-- ()
{
	return *this = double(variant(*this)) - 1;
}


apistring::apistring(const char* s)
{
	if (s >= (char*)0x10000)
	{
		int len = strlen(s);
		data = new char[len + 1];
		memcpy(data, s, len + 1);
	}
	else
		data = (char*)s;
}


apistring::apistring(const apistring& s)
{
	if (s.data >= (char*)0x10000)
	{
		int len = strlen(s.data);
		data = new char[len + 1];
		memcpy(data, s.data, len + 1);
	}
	else
		data = s.data;
}


apistring::apistring(const string& s)
{
	if (s.cstr() >= (char*)0x10000)
	{
		int len = s.length();
		data = new char[len + 1];
		memcpy(data, s.cstr(), len);
		data[len] = 0;
	}
	else
		data = (char*)s.cstr();
}


void apistring::alloc(int n)
{
	if (data >= (char*)0x10000)
		delete[] data;
	data = new char[n + 1];
	data[n] = 0;
}


int apistring::length() const
{
	if (data >= (char*)0x10000)
		return strlen(data);
	else
		return 0;
}


void apistring::operator= (const apistring& s)
{
	if (data >= (char*)0x10000)
		delete[] data;
	if (s.data >= (char*)0x10000)
	{
		int len = strlen(s.data);
		data = new char[len + 1];
		memcpy(data, s.data, len + 1);
	}
	else
		data = (char*)s.data;
}


void apistring::operator= (const string& s)
{
	if (data >= (char*)0x10000)
		delete[] data;
	if (s.cstr() >= (char*)0x10000)
	{
		int len = s.length();
		data = new char[len + 1];
		memcpy(data, &s, len);
		data[len] = 0;
	}
	else
		data = (char*)s.cstr();
}

variant::variant(double n)
{
	vartype = num;
	this->n = n;
	char tmp[256];
	sprintf(tmp, "%.16g", n);
	s = tmp;
}


variant::variant(const string& s)
{
	vartype = str;
	this->s = s;
	this->n = s.cstr() > (char*)0x10000 ? atof(s.cstr()) : 0;
}


variant& variant::operator= (const variant& v)
{
	vartype = v.vartype;
	if (vartype == num)
	{
		n = v.n;
		s = "";
	}
	else if (vartype == str)
	{
		n = 0;
		s = v.s;
	}
	return *this;
}


variant::operator double () const
{
	return n;
}


variant::operator string () const
{
	return s;
}


variant variant::operator+ (const variant& v) const
{
	return (vartype == str ? *this + string(v) : *this + double(v));
}


variant variant::operator- (const variant& v) const
{
	return (vartype == str ? *this - string(v) : *this - double(v));
}


variant variant::operator* (const variant& v) const
{
	return *this * double(v);
}


variant variant::operator/ (const variant& v) const
{
	return *this / double(v);
}


variant variant::operator% (const variant& v) const
{
	return *this % double(v);
}


bool variant::operator&& (const variant& v) const
{
	return *this && double(v);
}


bool variant::operator|| (const variant& v) const
{
	return *this || double(v);
}


variant variant::operator^ (const variant& v) const
{
	return *this || double(v);
}


bool variant::operator== (const variant& v) const
{
	return (vartype == str ? *this == string(v) : *this == double(v));
}


bool variant::operator!= (const variant& v) const
{
	return (vartype == str ? *this == string(v) : *this == double(v));
}


bool variant::operator< (const variant& v) const
{
	return (vartype == str ? *this < string(v) : *this < double(v));
}


bool variant::operator> (const variant& v) const
{
	return (vartype == str ? *this > string(v) : *this > double(v));
}


bool variant::operator<= (const variant& v) const
{
	return (vartype == str ? *this <= string(v) : *this <= double(v));
}


bool variant::operator>= (const variant& v) const
{
	return (vartype == str ? *this >= string(v) : *this >= double(v));
}


variant variant::operator+ (const string& s) const
{
	if (vartype == str)
		return this->s + s;
	else
		return *this + variant(s);
}


variant variant::operator- (const string& s) const
{
	if (vartype == str)
		return this->s + s;
	else
		return *this - variant(s);
}


variant variant::operator* (const string& s) const
{
	return this->s * s;
}


variant variant::operator/ (const string& s) const
{
	return this->s / s;
}


variant variant::operator% (const string& s) const
{
	return this->s % s;
}


bool variant::operator&& (const string& s) const
{
	return this->s && variant(s);
}


bool variant::operator|| (const string& s) const
{
	return this->s || variant(s);
}


variant variant::operator^ (const string& s) const
{
	return this->s ^ s;
}


bool variant::operator== (const string& s) const
{
	return (vartype == str ? this->s == s : *this == variant(s));
}


bool variant::operator!= (const string& s) const
{
	return (vartype == str ? this->s != s : *this != variant(s));
}


bool variant::operator< (const string& s) const
{
	return (vartype == str ? this->s < s : *this < variant(s));
}


bool variant::operator> (const string& s) const
{
	return (vartype == str ? this->s > s : *this > variant(s));
}


bool variant::operator<= (const string& s) const
{
	return (vartype == str ? this->s <= s : *this <= variant(s));
}


bool variant::operator>= (const string& s) const
{
	return (vartype == str ? this->s >= s : *this >= variant(s));
}

variant variant::operator+ (double n) const
{
	return (vartype == num ? this->n + n : double(*this + variant(n)));
}


variant variant::operator- (double n) const
{
	return (vartype == num ? this->n - n : double(*this - variant(n)));
}


variant variant::operator* (double n) const
{
	return this->n * n;
}


variant variant::operator/ (double n) const
{
	return this->n / n;
}


variant variant::operator% (double n) const
{
	return int(this->n) % int(n);
}


bool variant::operator&& (double n) const
{
	return this->n && n;
}


bool variant::operator|| (double n) const
{
	return this->n || n;
}


variant variant::operator^ (double n) const
{
	return int(this->n) ^ int(n);
}


bool variant::operator== (double n) const
{
	return (vartype == num ? this->n == n : *this == variant(n));
}


bool variant::operator!= (double n) const
{
	return (vartype == num ? this->n == n : *this != variant(n));
}


bool variant::operator< (double n) const
{
	return (vartype == num ? this->n < n : *this < variant(n));
}


bool variant::operator> (double n) const
{
	return (vartype == num ? this->n > n : *this > variant(n));
}


bool variant::operator<= (double n) const
{
	return (vartype == num ? this->n <= n : *this <= variant(n));
}


bool variant::operator>= (double n) const
{
	return (vartype == num ? this->n >= n : *this >= variant(n));
}


bool variant::operator== (const apistring& s) const
{
	//return variant(s) == v;
	return (vartype == str ? this->s == variant(s) : *this == variant(s));

}


/*
variant operator+ (double n, const variant& v)
{
	return variant(n) + v;
}


variant operator- (double n, const variant& v)
{
	return variant(n) - v;
}


variant operator* (double n, const variant& v)
{
	return variant(n) * v;
}


variant operator/ (double n, const variant& v)
{
	return variant(n) / v;
}


variant operator% (double n, const variant& v)
{
	return variant(n) % v;
}


bool operator&& (double n, const variant& v)
{
	return variant(n) && v;
}


bool operator|| (double n, const variant& v)
{
	return variant(n) || v;
}


variant operator^ (double n, const variant& v)
{
	return variant(n) ^ v;
}


bool operator== (double n, const variant& v)
{
	return variant(n) == v;
}


bool operator!= (double n, const variant& v)
{
	return variant(n) != v;
}


bool operator< (double n, const variant& v)
{
	return variant(n) < v;
}


bool operator> (double n, const variant& v)
{
	return variant(n) > v;
}


bool operator<= (double n, const variant& v)
{
	return variant(n) <= v;
}


bool operator>= (double n, const variant& v)
{
	return variant(n) >= v;
}


variant operator+ (const string& s, const variant& v)
{
	return variant(s) + v;
}


variant operator- (const string& s, const variant& v)
{
	return variant(s) - v;
}


variant operator* (const string& s, const variant& v)
{
	return variant(s) * v;
}


variant operator/ (const string& s, const variant& v)
{
	return variant(s) / v;
}


variant operator% (const string& s, const variant& v)
{
	return variant(s) % v;
}


bool operator&& (const string& s, const variant& v)
{
	return variant(s) && v;
}


bool operator|| (const string& s, const variant& v)
{
	return variant(s) || v;
}


variant operator^ (const string& s, const variant& v)
{
	return variant(s) ^ v;
}


bool operator== (const string& s, const variant& v)
{
	return variant(s) == v;
}


bool operator!= (const string& s, const variant& v)
{
	return variant(s) != v;
}


bool operator< (const string& s, const variant& v)
{
	return variant(s) < v;
}


bool operator> (const string& s, const variant& v)
{
	return variant(s) > v;
}


bool operator<= (const string& s, const variant& v)
{
	return variant(s) <= v;
}


bool operator>= (const string& s, const variant& v)
{
	return variant(s) >= v;
}
*/


Print& Print::operator<< (variant v)
{
	if (v.vartype == variant::num)
		_cprintf("%.16g", double(v));
	else if (v.vartype == variant::str)
		_cprintf("%s", string(v).cstr());
	return *this;
}


Input& Input::line(string& s)
{
	char ln[2048];
	fgets(ln, 2048, stdin);
	s = string(ln);
	return *this;
}


Input& Input::operator>> (variant& v)
{
	char tmp[256];
	scanf("%s", tmp);
	v = string(tmp);
	return *this;
}


Input& Input::operator>> (unsigned char& c)
{
	unsigned int tmp;
	scanf("%u", &tmp);
	c = tmp;
	return *this;
}


Input& Input::operator>> (unsigned short& n)
{
	unsigned int tmp;
	scanf("%u", &tmp);
	n = tmp;
	return *this;
}


Input& Input::operator>> (unsigned long& n)
{
	scanf("%U", &n);
	return *this;
}


Input& Input::operator>> (short& n)
{
	int tmp;
	scanf("%d", &tmp);
	n = tmp;
	return *this;
}


Input& Input::operator>> (int& n)
{
	scanf("%d", &n);
	return *this;
}


Input& Input::operator>> (float& n)
{
	scanf("%g", &n);
	return *this;
}


Input& Input::operator>> (double& n)
{
	float tmp;
	scanf("%g", &tmp);
	n = tmp;
	return *this;
}


Input& Input::operator>> (long double& n)
{
	float tmp;
	scanf("%g", &tmp);
	n = tmp;
	return *this;
}


Input& Input::operator>> (bool& n)
{
	int tmp;
	scanf("%d", &tmp);
	n = tmp;
	return *this;
}


Input& Input::operator>> (string& v)
{
	char tmp[256];
	scanf("%s", tmp);
	v = string(tmp);
	return *this;
}


void nullify(void* ptr, int size)
{
	memset(ptr, 0, size);
}

#ifndef __GNUWIN32__
	#define HINSTANCE Long
	#define DWORD Long
		
	#define LoadLibrary(x) 0
	#define FreeLibrary(x) 0
	#define GetModuleHandle(x) 0
	#define GetProcAddress(x,y) 0
	int GetCurrentThreadId() { return 100; }
#endif
	
std::vector<HINSTANCE> hlib;

void loadlib(const string& lib)
{
	hlib.push_back(LoadLibrary(lib.cstr()));
}

void unloadlibs()
{
	std::vector<HINSTANCE>::iterator i;
	for (i = hlib.begin(); i != hlib.end(); i++)
		FreeLibrary(*i);
}

void* getlibhandle(const string& lib)
{
	return GetModuleHandle(lib.cstr());
}

void* getprocaddr(void* lib, const string& func)
{
	return (void*)GetProcAddress((HINSTANCE)lib, func.cstr());
}
/*
int process_se(unsigned int se,unsigned int excToFilter)
{
	switch (se)
	{
	case EXCEPTION_ACCESS_VIOLATION:
		throw string("access violation");
	case EXCEPTION_FLT_DIVIDE_BY_ZERO:
	case EXCEPTION_INT_DIVIDE_BY_ZERO:
		throw string("division by zero");
	case EXCEPTION_FLT_INVALID_OPERATION:
		throw string("floating-point error");
	case EXCEPTION_ILLEGAL_INSTRUCTION:
		throw string("illegal instruction");
	case EXCEPTION_STACK_OVERFLOW:
		throw string("stack overflow");
	default:
		return 0;
	}
}

void exec_and_seh(void (*func)())
{
	__TRY {
		func();
	}
	__EXCEPT(process_se(GetExceptionCode(),EXCEPTION_STACK_OVERFLOW))
	{
	}
	__END__EXCEPT
}
*/

static std::map<DWORD, std::vector<string> > dbg_funcs;
static std::map<DWORD, std::vector<int> > dbg_lines;

void dbg_line(int n)
{
	dbg_lines[GetCurrentThreadId()].back() = n;
}

int dbg_getline()
{
	DWORD id = GetCurrentThreadId();
	if (dbg_lines[id].empty())
		return 0;
	
	int result = dbg_lines[id].back();
	dbg_lines[id].pop_back();
	
	return result;
}

string dbg_getfunc()
{
	DWORD id = GetCurrentThreadId();
	if (dbg_funcs[id].empty())
		return "nothing";
	
	string result = dbg_funcs[id].back();
	dbg_funcs[id].pop_back();
	return result;
}

void dbg_func(const string& s)
{
	DWORD id = GetCurrentThreadId();
	dbg_funcs[id].push_back(s);
	dbg_lines[id].push_back(0);
}

void dbg_endfunc()
{
	DWORD id = GetCurrentThreadId();
	dbg_funcs[id].pop_back();
	dbg_lines[id].pop_back();
}

int dbg_savefunc()
{
	return dbg_funcs[GetCurrentThreadId()].size();
}

void dbg_unwind(int n)
{
	DWORD id = GetCurrentThreadId();
	//dbg_funcs[id].clear();
    dbg_funcs[id].resize(n);
	dbg_lines[id].resize(n);
}



}

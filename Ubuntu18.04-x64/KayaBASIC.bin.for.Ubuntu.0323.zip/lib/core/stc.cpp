#include "core.h"
#include <stdlib.h>
#include <locale.h>
#include <iostream>

#ifdef __GNUWIN32__
	#include <windows.h>
#endif

using namespace bpp;

extern "C" void abort_with_error(const bpp::string& s)
{
	print << string("Error: ") << s << string("\r\n");
	while (true)
	{
		static bool first = true;
		int line = dbg_getline();
		string func = dbg_getfunc();
		if (!line)
			break;
		if (first)
		{
			print << string("    raised");
			first = false;
		}
		else
			print << string(",\r\n    called");
		print << string(" by ") << func << string("() at line #") << line;
	}
	
	print << string("\r\n");	
	exit(0);
}

namespace bpp {
	namespace System {
		extern bpp::array<string> Command;
	}
}

int main(int argc, char* argv[])
{
	setlocale(LC_ALL, "");
	
	bpp::System::Command.redim(0, argc);
	for ( int i = 0; i < argc; i++ ) {
		bpp::System::Command(i) = argv[i];
	}
	bpp::System::Command(argc) = "stc";
	
	#ifdef __GNUWIN32__
		CoInitialize(NULL);
	#endif
	
	try
	{
		__init_all();
		Main();
		__final_all();
	}
	catch (const string& s)
	{
		abort_with_error(s);
	}
	catch (...)
	{
		abort_with_error("");
	}

	#ifdef __GNUWIN32__
		CoUninitialize();
	#endif
	
	return 0;
}
